# Design Guidelines: Bloodline Builders LLC (Premium Edition)

## Design Approach
**Reference-Based Strategy**: Drawing inspiration from luxury hotel brands (Four Seasons, Ritz-Carlton) combined with high-end architectural firms (Zaha Hadid, Gensler). This elevated approach uses the company's heraldic crest as a foundation for a regal, sophisticated identity that commands authority in home services while maintaining approachability. Rich textures, dramatic photography, and refined typography create distinction from generic contractors.

**Core Principles**: Noble craftsmanship meets modern luxury. Deep jewel tones (burgundy, royal purple, antique gold) paired with crisp whites and charcoal grays. Generous whitespace creates breathing room. Every element reinforces premium positioning through refined details and confident scale.

## Typography System

**Primary Font**: Playfair Display (serif, for headlines - regal elegance)
- H1: 4rem (desktop), 2.75rem (mobile), font-weight: 700, tight leading (1.1)
- H2: 3rem (desktop), 2.25rem (mobile), font-weight: 600
- H3: 2rem, font-weight: 600

**Secondary Font**: Inter (sans-serif, for body and UI)
- Body: 1.125rem, font-weight: 400, line-height: 1.8
- Labels/Small: 0.875rem, font-weight: 500, letter-spacing: 0.05em (slight tracking)
- Navigation: 0.9375rem, font-weight: 500

**Accent Font**: Cinzel (for crest tagline, certifications) - Use sparingly for maximum impact

## Layout System

**Spacing Primitives**: Tailwind units of 4, 8, 12, 16, 24
- Section padding: py-24 (desktop), py-16 (mobile)
- Card spacing: p-8 to p-12
- Element gaps: gap-12 (desktop), gap-8 (mobile)

**Container Strategy**:
- Full-width sections with inner max-w-7xl for content areas
- Asymmetric layouts for visual interest (60/40 splits vs. rigid 50/50)

## Page Structure & Components

### Header
Sophisticated sticky navigation with centered crest logo, flanked by service menu links. Right side: phone number in elegant typography with gold accent icon, "Request Consultation" button with subtle gold border. Top bar above main nav: "Licensed • Insured • Serving Northeast Philadelphia Since [Year]" in small caps with letter-spacing.

### Hero Section
Full-viewport (85vh) hero featuring dramatic photograph of luxury home exterior or high-end renovation. Deep gradient overlay (dark purple to transparent) for text contrast. Centered headline in Playfair Display: "Masterful Craftsmanship for Distinguished Homes" with refined subheadline. Two CTAs with blurred backgrounds: primary "Schedule Consultation" (gold accent), secondary "Explore Services" (outlined). Service area badge: "Exclusively Serving 19114, 19115, 19116" in decorative frame. Include small crest watermark in corner.

### Services Showcase
Six premium service cards in 3-column grid with elegant borders. Each card: large service-specific icon in gold, service name in Playfair Display, sophisticated 3-line description, and "Discover More" link with arrow. Cards have subtle depth with refined shadows. Services: Climate Control Excellence (HVAC), Master Plumbing, Precision Electrical, Luxury Remodeling, Expert Repairs, Professional Demolition & Dumpster Services.

### Heritage & Excellence
Two-column asymmetric section (40/60 split). Left: Company crest large and prominent with founding story in refined typography. Right: Four pillars of distinction with gold accent icons - "Licensed Master Craftsmen", "24/7 Premium Service", "Transparent Investment", "Northeast Philly Legacy". Each with icon and elegant 2-sentence description.

### Portfolio Gallery
Luxury masonry grid with 8-10 high-end project photos. Mix of dramatic before/after transformations and completed luxury projects. Hover reveals project details in overlay with gold accent borders. Include mix of kitchens, bathrooms, HVAC installations, and exterior work - all premium quality imagery.

### Service Territory
Elegant map visualization of Northeast Philadelphia with refined gold highlighting of coverage zones. Decorative frame around map. Text in Cinzel: "Proudly Serving the Northeast Philadelphia Community" with zip codes in gold. Include response commitment: "Within 2 Hours for Emergencies".

### Client Testimonials
Three testimonial cards with refined styling. Each includes client name in Playfair Display, service received, five gold stars, and detailed review. Include client initials in circular gold-bordered avatars. Subtle background texture adds depth.

### Consultation Request
Split section with decorative divider. Left: Premium contact form with elegant inputs (Name, Phone, Service Selection, Project Details, Preferred Contact Time). Right: Contact details with gold accent icons, business hours in refined typography, emergency service callout in decorative box, and satisfaction guarantee badge. Large "Call Our Experts" button with phone number.

### Footer
Multi-column sophisticated layout with subtle top border. Columns: Services directory, Company (About, Careers, Testimonials), Contact Info with gold icons, Newsletter signup ("Seasonal Maintenance Insights for Distinguished Homeowners"). Bottom bar: Certifications, licenses, professional affiliations in refined badges. Copyright in small caps.

## Images

**Hero Image**: Dramatic twilight photograph of upscale Northeast Philadelphia home exterior or stunning luxury interior renovation (kitchen/bathroom). Professional photography with rich colors and excellent composition. Minimum 1920x1080, landscape orientation.

**Service Icons**: Font Awesome Pro or custom gold-colored icons for premium feel. Larger scale than typical service sites (3-4rem).

**Portfolio Images**: 8-10 professional photos of high-end completed projects. Mix interior and exterior. All should showcase premium materials, excellent lighting, and professional staging. Square format (1:1) for grid consistency.

**Heritage Image**: Professional photograph of company crest/logo in high resolution. Can include founder photo or team in branded premium workwear on luxury job site.

**Textures**: Subtle background textures (marble, brushed metal, linen) used sparingly for depth in hero and section backgrounds.

**Trust Elements**: Premium certification badges, license seals, and insurance verification rendered in gold/burgundy color scheme. BBB, professional association logos.