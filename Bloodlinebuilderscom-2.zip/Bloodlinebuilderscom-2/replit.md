# Bloodline Builders LLC

## Overview

A professional website for Bloodline Builders LLC, a home services company serving Northeast Philadelphia (zip codes 19114, 19115, 19116). The site showcases HVAC, plumbing, electrical, remodeling, small repairs, and demolition services. It features a contact form for customer inquiries, service descriptions, testimonials, and service area information.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with shadcn/ui component library (New York style)
- **State Management**: TanStack React Query for server state
- **Forms**: React Hook Form with Zod validation
- **Theming**: Custom theme provider with light/dark mode support

### Backend Architecture
- **Runtime**: Node.js with Express
- **API Design**: RESTful endpoints under `/api` prefix
- **Build System**: Vite for frontend, esbuild for server bundling
- **Development**: Hot module replacement via Vite dev server

### Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema**: Defined in `shared/schema.ts` with Zod integration via drizzle-zod
- **Storage**: Memory storage implementation currently in use (`server/storage.ts`), ready for PostgreSQL migration
- **Validation**: Zod schemas shared between client and server

### Project Structure
- `client/` - React frontend application
- `server/` - Express backend with API routes
- `shared/` - Shared types, schemas, and data definitions
- `migrations/` - Database migration files (Drizzle Kit)

### Key Design Patterns
- Shared schema validation between frontend and backend using Zod
- Component-based architecture with reusable UI primitives
- Path aliases (`@/`, `@shared/`) for clean imports
- Separation of concerns: pages, components, hooks, lib utilities

## External Dependencies

### Database
- **PostgreSQL**: Primary database (configured via `DATABASE_URL` environment variable)
- **Drizzle Kit**: Database migrations and schema management

### UI Component Libraries
- **Radix UI**: Headless component primitives (dialogs, menus, forms, etc.)
- **Lucide React**: Icon library
- **Embla Carousel**: Carousel functionality
- **React Day Picker**: Calendar components
- **Vaul**: Drawer component

### Build & Development
- **Vite**: Frontend build tool with React plugin
- **esbuild**: Server bundling for production
- **TypeScript**: Type checking across the codebase

### Form & Validation
- **React Hook Form**: Form state management
- **Zod**: Schema validation
- **@hookform/resolvers**: Zod integration for React Hook Form