import { pgTable, text, varchar, timestamp, serial, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { sql } from "drizzle-orm";

// Re-export chat models
export { conversations, messages, insertConversationSchema, insertMessageSchema } from "./models/chat";
export type { Conversation, InsertConversation, Message, InsertMessage } from "./models/chat";

export const users = pgTable("users", {
  id: varchar("id", { length: 36 }).primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const contactSubmissions = pgTable("contact_submissions", {
  id: varchar("id", { length: 36 }).primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  service: text("service").notNull(),
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertContactSchema = createInsertSchema(contactSubmissions).pick({
  name: true,
  phone: true,
  email: true,
  service: true,
  message: true,
}).extend({
  name: z.string().min(2, "Name must be at least 2 characters"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  email: z.string().email("Please enter a valid email").optional().or(z.literal("")),
  service: z.string().min(1, "Please select a service"),
  message: z.string().optional(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertContact = z.infer<typeof insertContactSchema>;
export type ContactSubmission = typeof contactSubmissions.$inferSelect;

export const services = [
  {
    id: "roadside",
    title: "24-Hour Roadside Assistance",
    description: "Stranded on the road? We've got you covered 24/7. Jump starts, tire changes, fuel delivery, and towing services available around the clock, day or night.",
    icon: "Car",
    is24Hour: true,
  },
  {
    id: "locksmith",
    title: "24-Hour Locksmith",
    description: "Locked out? Our certified locksmiths are available 24 hours a day, 7 days a week. Home, car, and commercial lockouts, rekeying, and lock installations.",
    icon: "Key",
    is24Hour: true,
  },
  {
    id: "hvac",
    title: "HVAC Services",
    description: "Complete heating and cooling solutions. Installation, repair, and maintenance of central air systems, furnaces, and heat pumps. Available 8AM - 7PM daily.",
    icon: "Thermometer",
    is24Hour: false,
  },
  {
    id: "plumbing",
    title: "Plumbing",
    description: "Expert pipe repair and replacement. From leaky faucets to complete repiping, we handle all your plumbing needs. Available 8AM - 7PM daily. 24-hour emergency service available.",
    icon: "Droplets",
    is24Hour: false,
  },
  {
    id: "electrical",
    title: "Electrical",
    description: "Safe and reliable electrical services. Panel upgrades, rewiring, outlet installation, and lighting solutions. Available 8AM - 7PM daily. 24-hour emergency service available.",
    icon: "Zap",
    is24Hour: false,
  },
  {
    id: "remodeling",
    title: "Remodeling",
    description: "Transform your space with our expert remodeling services. Kitchen, bathroom, and whole-home renovations. Available 8AM - 7PM daily.",
    icon: "Home",
    is24Hour: false,
  },
  {
    id: "repairs",
    title: "Small Repairs",
    description: "No job too small. Drywall patches, door repairs, fixture installations, and general handyman services. Available 8AM - 7PM daily.",
    icon: "Wrench",
    is24Hour: false,
  },
  {
    id: "demolition",
    title: "Demolition",
    description: "Professional demolition services. Interior teardowns, structure removal, and site preparation done right. Available 8AM - 7PM daily.",
    icon: "Hammer",
    is24Hour: false,
  },
  {
    id: "dumpster",
    title: "Dumpster Rental",
    description: "Convenient dumpster drop-off and pickup service. We deliver, you fill it, we haul it away when you're done. Perfect for cleanouts and projects. Available 8AM - 7PM daily.",
    icon: "Truck",
    is24Hour: false,
  },
] as const;

export const testimonials = [
  {
    id: 1,
    name: "Michael R.",
    service: "HVAC Installation",
    rating: 5,
    text: "Bloodline Builders replaced our entire HVAC system in just two days. Professional team, fair pricing, and our home has never been more comfortable.",
  },
  {
    id: 2,
    name: "Sarah T.",
    service: "Bathroom Remodel",
    rating: 5,
    text: "Transformed our outdated bathroom into a modern spa-like retreat. The attention to detail was incredible. Highly recommend!",
  },
  {
    id: 3,
    name: "James K.",
    service: "Electrical Rewiring",
    rating: 5,
    text: "Had our 1950s home completely rewired. The team was knowledgeable, clean, and finished ahead of schedule. Great experience.",
  },
] as const;

export const serviceAreas = [
  "Northeast Philadelphia",
  "Academy Gardens",
  "Ashton-Woodenbridge",
  "Bustleton",
  "Byberry",
  "Crestmont Farms",
  "Krewstown",
  "Millbrook",
  "Modena Park",
  "Morrell Park",
  "Normandy",
  "Parkwood",
  "Pennypack",
  "Pine Valley",
  "Somerton",
  "Torresdale",
  "Upper Holmesburg",
  "Winchester Park",
] as const;
