import { Header } from "@/components/header";
import { Hero } from "@/components/hero";
import { Services } from "@/components/services";
import { WhyUs } from "@/components/why-us";
import { Testimonials } from "@/components/testimonials";
import { ServiceArea } from "@/components/service-area";
import { ContactForm } from "@/components/contact-form";
import { Footer } from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <Hero />
        <Services />
        <WhyUs />
        <ServiceArea />
        <Testimonials />
        <ContactForm />
      </main>
      <Footer />
    </div>
  );
}
