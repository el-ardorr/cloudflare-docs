import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { 
  Send, 
  Plus, 
  Trash2, 
  MessageSquare, 
  ArrowLeft,
  Bot,
  User
} from "lucide-react";
import { Link } from "wouter";
import type { Conversation, Message } from "@shared/schema";

interface ConversationWithMessages extends Conversation {
  messages?: Message[];
}

export default function ChatPage() {
  const [activeConversation, setActiveConversation] = useState<number | null>(null);
  const [inputValue, setInputValue] = useState("");
  const [streamingMessage, setStreamingMessage] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const { data: conversations = [], isLoading: isLoadingConversations } = useQuery<Conversation[]>({
    queryKey: ["/api/conversations"],
  });

  const { data: activeChat, isLoading: isLoadingChat } = useQuery<ConversationWithMessages>({
    queryKey: ["/api/conversations", activeConversation],
    enabled: !!activeConversation,
  });

  const createConversation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/conversations", { title: "New Chat" });
      return res.json();
    },
    onSuccess: (data: Conversation) => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      setActiveConversation(data.id);
    },
  });

  const deleteConversation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/conversations/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      if (activeConversation) {
        setActiveConversation(null);
      }
    },
  });

  const sendMessage = async (content: string) => {
    if (!activeConversation || !content.trim()) return;

    setIsStreaming(true);
    setStreamingMessage("");
    setInputValue("");

    try {
      const response = await fetch(`/api/conversations/${activeConversation}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || "Failed to send message");
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      if (reader) {
        let fullMessage = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value);
          const lines = chunk.split("\n");

          for (const line of lines) {
            if (line.startsWith("data: ")) {
              try {
                const data = JSON.parse(line.slice(6));
                if (data.error) {
                  toast({
                    title: "Error",
                    description: data.error,
                    variant: "destructive",
                  });
                  setIsStreaming(false);
                  setStreamingMessage("");
                  queryClient.invalidateQueries({ queryKey: ["/api/conversations", activeConversation] });
                  return;
                }
                if (data.content) {
                  fullMessage += data.content;
                  setStreamingMessage(fullMessage);
                }
                if (data.done) {
                  setIsStreaming(false);
                  setStreamingMessage("");
                  queryClient.invalidateQueries({ queryKey: ["/api/conversations", activeConversation] });
                }
              } catch {
                // Skip invalid JSON
              }
            }
          }
        }
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to send message. Please try again.",
        variant: "destructive",
      });
      setIsStreaming(false);
      queryClient.invalidateQueries({ queryKey: ["/api/conversations", activeConversation] });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim() && !isStreaming) {
      sendMessage(inputValue);
    }
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [activeChat?.messages, streamingMessage]);

  useEffect(() => {
    if (activeConversation && inputRef.current) {
      inputRef.current.focus();
    }
  }, [activeConversation]);

  const messages = activeChat?.messages || [];

  return (
    <div className="min-h-screen bg-background">
      <div className="flex h-screen">
        <aside className="w-72 border-r bg-card flex flex-col">
          <div className="p-4 border-b">
            <Link href="/">
              <Button variant="ghost" size="sm" className="mb-3 gap-2" data-testid="link-back-home">
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Button>
            </Link>
            <Button
              onClick={() => createConversation.mutate()}
              className="w-full gap-2"
              disabled={createConversation.isPending}
              data-testid="button-new-chat"
            >
              <Plus className="h-4 w-4" />
              New Conversation
            </Button>
          </div>

          <ScrollArea className="flex-1">
            <div className="p-2 space-y-1">
              {isLoadingConversations ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))
              ) : conversations.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8 px-4">
                  No conversations yet. Start a new chat to get help with your home service questions.
                </p>
              ) : (
                conversations.map((conv) => (
                  <div
                    key={conv.id}
                    className={`group flex items-center gap-2 p-3 rounded-md cursor-pointer hover-elevate ${
                      activeConversation === conv.id ? "bg-accent" : ""
                    }`}
                    onClick={() => setActiveConversation(conv.id)}
                    data-testid={`conversation-item-${conv.id}`}
                  >
                    <MessageSquare className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    <span className="flex-1 truncate text-sm">{conv.title}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteConversation.mutate(conv.id);
                      }}
                      data-testid={`button-delete-conversation-${conv.id}`}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </aside>

        <main className="flex-1 flex flex-col">
          {activeConversation ? (
            <>
              <header className="border-b p-4">
                <h1 className="text-lg font-semibold" data-testid="text-chat-title">
                  {activeChat?.title || "Chat"}
                </h1>
                <p className="text-sm text-muted-foreground">
                  Ask about HVAC, plumbing, electrical, remodeling, and more
                </p>
              </header>

              <ScrollArea className="flex-1 p-4" ref={scrollRef}>
                <div className="max-w-3xl mx-auto space-y-4">
                  {isLoadingChat ? (
                    Array.from({ length: 3 }).map((_, i) => (
                      <Skeleton key={i} className="h-20 w-full" />
                    ))
                  ) : messages.length === 0 && !streamingMessage ? (
                    <div className="text-center py-12">
                      <Bot className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                      <h2 className="text-xl font-semibold mb-2">How can I help you today?</h2>
                      <p className="text-muted-foreground max-w-md mx-auto">
                        I'm your Bloodline Builders assistant. Ask me about our services, get estimates, or learn about home maintenance.
                      </p>
                    </div>
                  ) : (
                    <>
                      {messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex gap-3 ${
                            message.role === "user" ? "justify-end" : "justify-start"
                          }`}
                          data-testid={`message-${message.id}`}
                        >
                          {message.role === "assistant" && (
                            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                              <Bot className="h-4 w-4 text-primary-foreground" />
                            </div>
                          )}
                          <Card
                            className={`max-w-[80%] p-3 ${
                              message.role === "user"
                                ? "bg-primary text-primary-foreground"
                                : "bg-card"
                            }`}
                          >
                            <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                          </Card>
                          {message.role === "user" && (
                            <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                              <User className="h-4 w-4" />
                            </div>
                          )}
                        </div>
                      ))}
                      {streamingMessage && (
                        <div className="flex gap-3 justify-start">
                          <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                            <Bot className="h-4 w-4 text-primary-foreground" />
                          </div>
                          <Card className="max-w-[80%] p-3 bg-card">
                            <p className="text-sm whitespace-pre-wrap">{streamingMessage}</p>
                          </Card>
                        </div>
                      )}
                    </>
                  )}
                </div>
              </ScrollArea>

              <footer className="border-t p-4">
                <form onSubmit={handleSubmit} className="max-w-3xl mx-auto flex gap-2">
                  <Input
                    ref={inputRef}
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="Type your message..."
                    disabled={isStreaming}
                    className="flex-1"
                    data-testid="input-message"
                  />
                  <Button
                    type="submit"
                    disabled={!inputValue.trim() || isStreaming}
                    data-testid="button-send-message"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </form>
              </footer>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <MessageSquare className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                <h2 className="text-2xl font-semibold mb-2">Welcome to Chat</h2>
                <p className="text-muted-foreground mb-6 max-w-md">
                  Get instant answers about our home services. Start a new conversation or select an existing one.
                </p>
                <Button
                  onClick={() => createConversation.mutate()}
                  disabled={createConversation.isPending}
                  className="gap-2"
                  data-testid="button-start-chat"
                >
                  <Plus className="h-4 w-4" />
                  Start New Chat
                </Button>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
