import { useState } from "react";
import { Link } from "wouter";
import { Menu, X, Phone, Shield, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";
import logoImage from "@assets/IMG_5722_1767557212528.jpeg";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navLinks = [
    { href: "#services", label: "Services" },
    { href: "#why-us", label: "Why Us" },
    { href: "#testimonials", label: "Testimonials" },
    { href: "#contact", label: "Contact" },
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
    setIsMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-18 items-center justify-between gap-4 py-2">
          <Link href="/" className="flex items-center gap-3" data-testid="link-home">
            <img 
              src={logoImage} 
              alt="Bloodline Builders LLC" 
              className="h-14 w-14 object-contain"
            />
            <div className="hidden sm:block">
              <span className="font-serif text-xl font-bold tracking-tight">Bloodline Builders</span>
              <span className="ml-1.5 text-xs text-muted-foreground">LLC</span>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => scrollToSection(link.href)}
                className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
                data-testid={`link-${link.label.toLowerCase().replace(" ", "-")}`}
              >
                {link.label}
              </button>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Shield className="h-3.5 w-3.5" />
              <span>24/7 Service</span>
            </div>
            <a
              href="tel:+12673210577"
              className="flex items-center gap-2 text-sm font-semibold"
              data-testid="link-phone"
            >
              <Phone className="h-4 w-4" />
              <span>(267) 321-0577</span>
            </a>
            <Link href="/chat">
              <Button variant="outline" className="gap-2" data-testid="button-chat-header">
                <MessageSquare className="h-4 w-4" />
                Chat
              </Button>
            </Link>
            <Button
              onClick={() => scrollToSection("#contact")}
              data-testid="button-get-quote-header"
            >
              Get Free Quote
            </Button>
            <ThemeToggle />
          </div>

          <div className="flex md:hidden items-center gap-2">
            <ThemeToggle />
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden border-t bg-background">
          <div className="px-4 py-4 space-y-3">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => scrollToSection(link.href)}
                className="block w-full text-left py-2 text-sm font-medium text-muted-foreground hover:text-foreground"
                data-testid={`link-mobile-${link.label.toLowerCase().replace(" ", "-")}`}
              >
                {link.label}
              </button>
            ))}
            <div className="pt-3 border-t space-y-3">
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-2">
                <Shield className="h-3.5 w-3.5" />
                <span>24/7 Emergency Service Available</span>
              </div>
              <a
                href="tel:+12673210577"
                className="flex items-center gap-2 text-sm font-semibold"
                data-testid="link-phone-mobile"
              >
                <Phone className="h-4 w-4" />
                <span>(267) 321-0577</span>
              </a>
              <Link href="/chat" onClick={() => setIsMenuOpen(false)}>
                <Button variant="outline" className="w-full gap-2" data-testid="button-chat-mobile">
                  <MessageSquare className="h-4 w-4" />
                  Chat with AI Assistant
                </Button>
              </Link>
              <Button
                className="w-full"
                onClick={() => scrollToSection("#contact")}
                data-testid="button-get-quote-mobile"
              >
                Get Free Quote
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
