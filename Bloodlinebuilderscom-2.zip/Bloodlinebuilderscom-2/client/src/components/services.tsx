import { Thermometer, Droplets, Zap, Home, Wrench, Hammer, Truck, ArrowRight, Car, Key, Clock } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { services } from "@shared/schema";

const iconMap: Record<string, React.ElementType> = {
  Thermometer,
  Droplets,
  Zap,
  Home,
  Wrench,
  Hammer,
  Truck,
  Car,
  Key,
};

export function Services() {
  const scrollToContact = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="services" className="py-24 md:py-32 bg-muted/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16 md:mb-20">
          <p className="text-sm uppercase tracking-widest text-primary font-medium mb-3">What We Offer</p>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight mb-5">
            24-Hour Premium Services
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Comprehensive solutions delivered by master craftsmen, available 24 hours a day, 7 days a week.
            Emergency roadside assistance, locksmith, home improvement, and more.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => {
            const Icon = iconMap[service.icon];
            return (
              <Card
                key={service.id}
                className="group relative overflow-visible hover-elevate border-2"
                data-testid={`card-service-${service.id}`}
              >
                {service.is24Hour && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-10">
                    <Badge variant="default" className="gap-1 text-xs" data-testid={`badge-24hr-${service.id}`}>
                      <Clock className="h-3 w-3" />
                      24/7 Service
                    </Badge>
                  </div>
                )}
                <CardHeader className="pb-4 pt-6">
                  <div className="flex flex-col items-center text-center gap-4">
                    <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 text-primary">
                      <Icon className="h-8 w-8" />
                    </div>
                    <CardTitle className="font-serif text-xl">{service.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="pt-0 text-center">
                  <CardDescription className="text-sm leading-relaxed mb-6">
                    {service.description}
                  </CardDescription>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={scrollToContact}
                    data-testid={`button-learn-more-${service.id}`}
                  >
                    Request Quote
                    <ArrowRight className="ml-1.5 h-3.5 w-3.5" />
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
