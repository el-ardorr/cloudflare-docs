import { MapPin, Clock, Phone } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { serviceAreas } from "@shared/schema";

export function ServiceArea() {
  return (
    <section className="py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-primary to-primary/80 rounded-2xl overflow-hidden">
          <div className="grid lg:grid-cols-2 gap-10 p-10 md:p-14">
            <div className="text-primary-foreground">
              <p className="text-sm uppercase tracking-widest opacity-80 font-medium mb-3">Our Territory</p>
              <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight mb-5">
                Proudly Serving Northeast Philadelphia
              </h2>
              <p className="text-lg opacity-90 mb-10 leading-relaxed">
                We're your local experts, serving the following neighborhoods with fast response 
                times and personalized service. When you call Bloodline Builders, you're 
                calling a neighbor.
              </p>

              <div className="flex flex-wrap gap-2 mb-8">
                {serviceAreas.map((area) => (
                  <Badge
                    key={area}
                    variant="secondary"
                    className="text-sm px-3 py-1"
                    data-testid={`badge-area-${area.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    {area}
                  </Badge>
                ))}
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <a href="tel:+12673210577" data-testid="link-call-now">
                  <Button
                    size="lg"
                    variant="secondary"
                    className="w-full sm:w-auto"
                  >
                    <Phone className="h-4 w-4 mr-2" />
                    Call (267) 321-0577
                  </Button>
                </a>
              </div>
            </div>

            <div className="flex flex-col justify-center gap-6">
              <div className="bg-primary-foreground/10 backdrop-blur rounded-xl p-6">
                <div className="flex items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary-foreground/20">
                    <Clock className="h-6 w-6 text-primary-foreground" />
                  </div>
                  <div className="text-primary-foreground">
                    <h3 className="font-semibold text-lg">Response Time</h3>
                    <p className="text-sm opacity-90">
                      Same-day service available for most calls
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-primary-foreground/10 backdrop-blur rounded-xl p-6">
                <div className="flex items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary-foreground/20">
                    <MapPin className="h-6 w-6 text-primary-foreground" />
                  </div>
                  <div className="text-primary-foreground">
                    <h3 className="font-semibold text-lg">Local Expertise</h3>
                    <p className="text-sm opacity-90">
                      We know NE Philly homes inside and out
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
