import { Link } from "wouter";
import { Phone, Mail, MapPin } from "lucide-react";
import { services, serviceAreas } from "@shared/schema";
import logoImage from "@assets/IMG_5722_1767557212528.jpeg";

export function Footer() {
  const currentYear = new Date().getFullYear();

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-card border-t">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="py-16 md:py-20">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-10">
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center gap-3 mb-5">
                <img 
                  src={logoImage} 
                  alt="Bloodline Builders LLC" 
                  className="h-14 w-14 object-contain"
                />
                <div>
                  <span className="font-serif text-lg font-bold tracking-tight">Bloodline Builders</span>
                  <span className="ml-1.5 text-xs text-muted-foreground">LLC</span>
                </div>
              </div>
              <p className="text-sm text-muted-foreground mb-5 leading-relaxed">
                Premium home services you can trust. Serving Northeast Philadelphia for over 15 years.
              </p>
              <div className="space-y-2 text-sm">
                <a
                  href="tel:+12673210577"
                  className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
                  data-testid="footer-link-phone"
                >
                  <Phone className="h-4 w-4" />
                  (267) 321-0577
                </a>
                <a
                  href="mailto:sardortnyc@outlook.com"
                  className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
                  data-testid="footer-link-email"
                >
                  <Mail className="h-4 w-4" />
                  sardortnyc@outlook.com
                </a>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Services</h3>
              <ul className="space-y-2 text-sm">
                {services.map((service) => (
                  <li key={service.id}>
                    <button
                      onClick={() => scrollToSection("#services")}
                      className="text-muted-foreground hover:text-foreground transition-colors"
                      data-testid={`footer-link-${service.id}`}
                    >
                      {service.title}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-sm">
                {[
                  { label: "Home", href: "#" },
                  { label: "Services", href: "#services" },
                  { label: "Why Us", href: "#why-us" },
                  { label: "Testimonials", href: "#testimonials" },
                  { label: "Contact", href: "#contact" },
                ].map((link) => (
                  <li key={link.label}>
                    <button
                      onClick={() => link.href === "#" ? window.scrollTo({ top: 0, behavior: "smooth" }) : scrollToSection(link.href)}
                      className="text-muted-foreground hover:text-foreground transition-colors"
                      data-testid={`footer-link-${link.label.toLowerCase()}`}
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Service Areas</h3>
              <ul className="space-y-1 text-sm">
                {serviceAreas.slice(0, 8).map((area) => (
                  <li key={area} className="text-muted-foreground text-xs">
                    {area}
                  </li>
                ))}
                <li className="text-muted-foreground text-xs mt-1">
                  + {serviceAreas.length - 8} more neighborhoods
                </li>
              </ul>
              <div className="mt-4 pt-4 border-t">
                <p className="text-xs text-muted-foreground">
                  Licensed & Insured
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs text-muted-foreground text-center sm:text-left">
              &copy; {currentYear} Bloodline Builders LLC. All rights reserved.
            </p>
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span>Northeast Philadelphia, PA</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
