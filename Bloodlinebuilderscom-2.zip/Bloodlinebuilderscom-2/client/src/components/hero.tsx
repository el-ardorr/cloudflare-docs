import { Phone, ArrowRight, MapPin, Clock, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { serviceAreas } from "@shared/schema";

export function Hero() {
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-primary/10 via-background to-secondary/10">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,hsl(350_65%_35%/0.08),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,hsl(40_75%_50%/0.06),transparent_50%)]" />
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMtOS45NDEgMC0xOCA4LjA1OS0xOCAxOHM4LjA1OSAxOCAxOCAxOCAxOC04LjA1OSAxOC0xOC04LjA1OS0xOC0xOC0xOHptMCAzMmMtNy43MzIgMC0xNC02LjI2OC0xNC0xNHM2LjI2OC0xNCAxNC0xNCAxNCA2LjI2OCAxNCAxNC02LjI2OCAxNC0xNCAxNHoiIGZpbGw9IiM4ODg4ODgiIGZpbGwtb3BhY2l0eT0iMC4wMiIvPjwvZz48L3N2Zz4=')] opacity-30" />
      
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20 md:py-28">
        <div className="text-center max-w-4xl mx-auto">
          <Badge variant="secondary" className="mb-4 px-4 py-1.5 text-sm tracking-wide">
            <MapPin className="h-3.5 w-3.5 mr-2" />
            Serving Northeast Philadelphia
          </Badge>

          <Card className="inline-flex items-center gap-3 px-5 py-3 mb-6 bg-primary/10 border-primary/20" data-testid="banner-free-estimates">
            <div className="flex items-center justify-center h-10 w-10 rounded-full bg-primary/20">
              <Clock className="h-5 w-5 text-primary" />
            </div>
            <div className="text-left">
              <p className="font-semibold text-foreground">Free Estimates</p>
              <p className="text-sm text-muted-foreground flex items-center gap-1">
                <Calendar className="h-3.5 w-3.5" />
                Mon-Fri, 3PM - 8PM
              </p>
            </div>
          </Card>
          
          <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6">
            Masterful Craftsmanship
            <span className="block text-primary mt-2">For Distinguished Homes</span>
          </h1>
          
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
            From 24-hour roadside assistance and locksmith services to HVAC, plumbing, electrical, and more, 
            Bloodline Builders LLC delivers exceptional quality for all your needs. <span className="font-semibold text-foreground">Available 24 hours a day, 7 days a week.</span>
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <Button
              size="lg"
              onClick={() => scrollToSection("#contact")}
              className="w-full sm:w-auto text-base"
              data-testid="button-schedule-service"
            >
              Schedule Service
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => scrollToSection("#services")}
              className="w-full sm:w-auto text-base"
              data-testid="button-view-services"
            >
              View Our Services
            </Button>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2">
            <span className="text-sm text-muted-foreground">Service Areas:</span>
            {serviceAreas.map((area) => (
              <Badge key={area} variant="outline">
                {area}
              </Badge>
            ))}
          </div>
        </div>

        <div className="mt-20 grid grid-cols-2 sm:grid-cols-4 gap-8 max-w-4xl mx-auto">
          {[
            { label: "Years Experience", value: "15+" },
            { label: "Projects Completed", value: "500+" },
            { label: "Happy Customers", value: "300+" },
            { label: "5-Star Reviews", value: "150+" },
          ].map((stat) => (
            <div key={stat.label} className="text-center p-4">
              <div className="font-serif text-3xl sm:text-4xl font-bold text-primary mb-1" data-testid={`stat-${stat.label.toLowerCase().replace(" ", "-")}`}>
                {stat.value}
              </div>
              <div className="text-xs sm:text-sm text-muted-foreground tracking-wide uppercase">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 hidden md:block">
        <button
          onClick={() => scrollToSection("#services")}
          className="animate-bounce text-muted-foreground hover:text-foreground transition-colors"
          aria-label="Scroll to services"
          data-testid="button-scroll-down"
        >
          <svg
            className="h-6 w-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19 14l-7 7m0 0l-7-7m7 7V3"
            />
          </svg>
        </button>
      </div>
    </section>
  );
}
