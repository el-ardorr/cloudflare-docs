import { Shield, Clock, DollarSign, MapPin, CheckCircle2 } from "lucide-react";

const benefits = [
  {
    icon: Clock,
    title: "24/7 Availability",
    description: "We never close. Day or night, weekends and holidays, our team is ready to help with any emergency or scheduled service.",
  },
  {
    icon: Shield,
    title: "Licensed & Insured",
    description: "Fully licensed contractors with comprehensive insurance coverage for your complete peace of mind.",
  },
  {
    icon: DollarSign,
    title: "Transparent Pricing",
    description: "No hidden fees or surprises. Receive a detailed, clear estimate before any work begins.",
  },
  {
    icon: MapPin,
    title: "Northeast Philadelphia Experts",
    description: "Proudly serving our neighbors across 18 neighborhoods with fast response times.",
  },
];

export function WhyUs() {
  return (
    <section id="why-us" className="py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-20 items-center">
          <div>
            <p className="text-sm uppercase tracking-widest text-primary font-medium mb-3">Why Choose Us</p>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight mb-6">
              The Bloodline
              <span className="text-primary"> Difference</span>
            </h2>
            <p className="text-lg text-muted-foreground mb-10 leading-relaxed">
              For over 15 years, we've been the trusted choice for home services in Northeast 
              Philadelphia. Our commitment to excellence and customer satisfaction sets us apart.
            </p>

            <div className="space-y-8">
              {benefits.map((benefit) => (
                <div
                  key={benefit.title}
                  className="flex gap-5"
                  data-testid={`benefit-${benefit.title.toLowerCase().replace(/[^a-z0-9]/g, "-")}`}
                >
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 text-primary">
                    <benefit.icon className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-serif font-semibold text-lg mb-1">{benefit.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {benefit.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="bg-card rounded-lg border-2 p-10">
              <h3 className="font-serif text-2xl font-semibold mb-8">Our Promise to You</h3>
              <ul className="space-y-5">
                {[
                  "Complimentary, no-obligation estimates",
                  "Clean, respectful work environment",
                  "Clear communication throughout",
                  "Complete satisfaction guaranteed",
                  "Flexible scheduling options",
                  "Premium materials and workmanship",
                ].map((item) => (
                  <li key={item} className="flex items-center gap-4">
                    <CheckCircle2 className="h-5 w-5 text-secondary shrink-0" />
                    <span className="text-sm">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="absolute -bottom-4 -right-4 -z-10 h-full w-full rounded-lg bg-gradient-to-br from-primary/10 to-secondary/10" />
          </div>
        </div>
      </div>
    </section>
  );
}
